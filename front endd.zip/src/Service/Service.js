import React,{useState} from 'react'
import Navbar from '../Dashboard/Navbar'
import Footer from '../Dashboard/Footer'
import { RiMedal2Fill } from "react-icons/ri";
import { IoCarSportSharp } from "react-icons/io5";
import { MdSecurity } from "react-icons/md";
import { BiAlarm } from "react-icons/bi";
import { IoSpeedometerOutline } from "react-icons/io5";
import { FaUserTie } from "react-icons/fa";
import '../Service/service.css'

const Blog = () => {
  return (
    <>
      <title>Service - Speedo Car Rental</title>
      <Navbar />
      <div className="main-title">
        <h3>Our Services</h3>
        <h5 className='text-light'>Provide services by speedo</h5>
      </div>
      <div class="container-fluid col-12 d-flex">
        <div class="Card col-lg-4 col-md-4 col-sm-4">
          <div class="face face1">
            <div class="content">
              <h2>Best Price</h2>
              <p>Text is the exact, original words written by an author. Text is also a specific work as written by the original author..</p>
              <a href="#">Read More</a>
            </div>
          </div>
          <div class="face face2">
            <h2><RiMedal2Fill /></h2>
          </div>
        </div>
        <div class="Card col-lg-4 col-md-4 col-sm-4">
          <div class="face face1">
            <div class="content">
              <h2>Best Car</h2>
              <p>Text is the exact, original words written by an author. Text is also a specific work as written by the original author..</p>
              <a href="#">Read More</a>
            </div>
          </div>
          <div class="face face2">
            <h2><IoCarSportSharp /></h2>
          </div>
        </div>

        <div class="Card col-lg-4 col-md-4 col-sm-4">
          <div class="face face1">
            <div class="content">
              <h2>Security</h2>
              <p>Text is the exact, original words written by an author. Text is also a specific work as written by the original author..</p>
              <a href="#">Read More</a>
            </div>
          </div>
          <div class="face face2">
            <h2><MdSecurity /></h2>
          </div>
        </div>
      </div>
      <div class="container-fluid col-12 d-flex">
        <div class="Card col-lg-4 col-md-4 col-sm-4">
          <div class="face face1">
            <div class="content">
              <h2>Driver</h2>
              <p>Text is the exact, original words written by an author. Text is also a specific work as written by the original author..</p>
              <a href="#">Read More</a>
            </div>
          </div>
          <div class="face face2">
            <h2><FaUserTie /></h2>
          </div>
        </div>
        <div class="Card col-lg-4 col-md-4 col-sm-4">
          <div class="face face1">
            <div class="content">
              <h2>Fast Delivery</h2>
              <p>Text is the exact, original words written by an author. Text is also a specific work as written by the original author..</p>
              <a href="#">Read More</a>
            </div>
          </div>
          <div class="face face2">
            <h2><IoSpeedometerOutline /></h2>
          </div>
        </div>

        <div class="Card col-lg-4 col-md-4 col-sm-4">
          <div class="face face1">
            <div class="content">
              <h2>24*7 Customer</h2>
              <p>Text is the exact, original words written by an author. Text is also a specific work as written by the original author..</p>
              <a href="#">Read More</a>
            </div>
          </div>
          <div class="face face2">
            <h2><BiAlarm /></h2>
          </div>
        </div>
      </div>
      <Footer />
    </>
  )
}

export default Blog
