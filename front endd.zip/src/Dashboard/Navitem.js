

export const Navitem = [
  {
    title: "Home",
    path: "/Home",
  },
  {
    title: "About",
    path: "/About",
  },
  {
    title: "Popular Fleets",
    path: "/Populer",
  },
  {
    title: "Blog",
    path: "/blog",
  },
  {
    title: "Driver",
    path: "/driver",
  },

  {
    title: "Book Now",
    path: "/Book",
  },
  {
    title: "Contact",
    path: "/Contact",
  },
  {
    title: "Feedback",
    path: "/FeedBack",

  },
  {
    title: "Profile",
    path: "/ShowProfile",
  },
  {
    title: "Logout",
    path: "/Login",
  },
];

