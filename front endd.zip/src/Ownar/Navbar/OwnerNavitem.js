export const OwnerNavitem = [
  {
    title: "Dashboard",
    path: "/Dashboard",
  },
  {
    title: "AddCar",
    path: "/CarTabel",
  },
  {
    title: "Book Data",
    path: "/BookData",
  },
  {
    title: "Contact Data",
    path: "/ContactData",
  },
  {
    title: "State Data",
    path: "/StateTabel",
  },
  {
    title: "Driver Data",
    path: "/DriverTabel",
  },
  {
    title: "Logout",
    path: "/login",
  },


];
